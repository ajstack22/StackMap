// state.js - Application state management
// === APP STATE MANAGEMENT ===

class AppState {
    constructor() {
        // Activities array
        this.activities = [];
        
        // UI state
        this.ui = {
            editMode: false,
            editingCardIndex: -1,
            showingNewCardForm: false,
            selectedEmoji: CONFIG.DEFAULT_EMOJI,
            draggedElement: null
        };
        
        // Settings with defaults
        this.settings = {
            title: 'My StackMap',
            subtitle: '',
            backgroundColor: '#667eea',
            showNumbers: true,
            showCompletionIndicators: true,
            isDefaultTitle: true
        };
        
        // Callback for state changes
        this.onStateChange = null;
    }
    
    // THEME MANAGEMENT
    applyTheme() {
        const color = this.settings.backgroundColor || '#667eea';
        document.documentElement.style.setProperty('--primary-color', color);
        document.documentElement.style.setProperty('--background-gradient-start', color);
        
        // Create darker variant
        const hex = color.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        
        // Create darker color
        const darkerR = Math.max(0, r - 60);
        const darkerG = Math.max(0, g - 60);
        const darkerB = Math.max(0, b - 60);
        const darkerColor = `rgb(${darkerR}, ${darkerG}, ${darkerB})`;
        
        document.documentElement.style.setProperty('--primary-dark', darkerColor);
        document.documentElement.style.setProperty('--background-gradient-end', darkerColor);
        
        // Apply completion indicator visibility
        if (this.settings.showCompletionIndicators === false) {
            document.body.classList.add('hide-completion-indicators');
        } else {
            document.body.classList.remove('hide-completion-indicators');
        }
        
        // Update logo colors to match theme
        // This ensures logos are correct color on page load/refresh
        if (window.appInstance && window.appInstance.preferencesManager) {
            window.appInstance.preferencesManager.updateLogoColors(color);
        } else {
            // If app isn't fully initialized yet, defer the update
            setTimeout(() => {
                if (window.appInstance && window.appInstance.preferencesManager) {
                    window.appInstance.preferencesManager.updateLogoColors(color);
                }
            }, 100);
        }
    }
    
    updateTheme(color) {
        this.settings.backgroundColor = color;
        this.applyTheme();
        this._triggerSave();
    }
    
    // ACTIVITY MANAGEMENT
    addActivity(activity, position = 'top') {
        if (this.activities.length >= CONFIG.MAX_ACTIVITIES) {
            throw new Error(`Maximum of ${CONFIG.MAX_ACTIVITIES} activities allowed`);
        }
        
        const newActivity = {
            id: Date.now(),
            title: activity.title || 'New Activity',
            description: activity.description || '',
            icon: activity.icon || CONFIG.DEFAULT_EMOJI,
            completed: false,
            visible: true
        };
        
        if (position === 'bottom') {
            this.activities.push(newActivity);
        } else {
            this.activities.unshift(newActivity);
        }
        
        this._triggerSave();
    }
    
    updateActivity(index, updates) {
        if (index >= 0 && index < this.activities.length) {
            this.activities[index] = { ...this.activities[index], ...updates };
            this._triggerSave();
        }
    }
    
    removeActivity(index) {
        if (index >= 0 && index < this.activities.length) {
            this.activities.splice(index, 1);
            this._triggerSave();
        }
    }
    
    moveActivity(fromIndex, toIndex) {
        if (fromIndex === toIndex) return;
        if (fromIndex < 0 || fromIndex >= this.activities.length) return;
        if (toIndex < 0 || toIndex >= this.activities.length) return;
        
        const [movedActivity] = this.activities.splice(fromIndex, 1);
        this.activities.splice(toIndex, 0, movedActivity);
        
        this._triggerSave();
    }
    
    toggleActivityCompletion(index) {
        if (index >= 0 && index < this.activities.length) {
            this.activities[index].completed = !this.activities[index].completed;
            this._triggerSave();
        }
    }
    
    toggleActivityVisibility(index) {
        if (index >= 0 && index < this.activities.length) {
            this.activities[index].visible = !this.activities[index].visible;
            this._triggerSave();
        }
    }
    
    // SETTINGS MANAGEMENT
    updateTitle(title) {
        this.settings.title = title;
        this.settings.isDefaultTitle = (title === 'My StackMap');
        this._triggerSave();
    }
    
    // DATA IMPORT/EXPORT
    exportData() {
        return {
            version: '1.0',
            activities: this.activities,
            settings: this.settings
        };
    }
    
    importData(data) {
        if (data.activities && Array.isArray(data.activities)) {
            // Validate and clean activities
            this.activities = data.activities.map(activity => ({
                id: activity.id || Date.now() + Math.random(),
                title: activity.title || 'Untitled',
                description: activity.description || '',
                icon: activity.icon || CONFIG.DEFAULT_EMOJI,
                completed: !!activity.completed,
                visible: activity.visible !== false
            }));
        }
        
        if (data.settings) {
            this.settings = {
                ...this.settings,
                ...data.settings,
                // Ensure defaults for new properties
                showNumbers: data.settings.showNumbers !== false,
                showCompletionIndicators: data.settings.showCompletionIndicators !== false,
                isDefaultTitle: data.settings.isDefaultTitle !== false
            };
        }
        
        this.applyTheme();
        this._triggerSave();
    }
    
    // INTERNAL
    _triggerSave() {
        if (this.onStateChange) {
            this.onStateChange();
        }
    }
}

// Make available globally
window.AppState = AppState;