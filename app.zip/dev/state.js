// state.js - Application state management
// === STATE MANAGEMENT ===
class AppState {
    constructor() {
        this.activities = [];
        this.settings = {
            title: 'My StackMap',
            subtitle: 'Routine Ready',
            isDefaultTitle: true,
            backgroundColor: CONFIG.DEFAULT_COLOR,
            showNumbers: CONFIG.SHOW_NUMBERS_DEFAULT,
            showCompletionIndicators: CONFIG.SHOW_COMPLETION_DEFAULT
        };
        this.ui = {
            editMode: false,
            editingCardIndex: -1,
            showingNewCardForm: false,
            selectedEmoji: CONFIG.DEFAULT_EMOJI,
            draggedElement: null
        };
        
        // External save handler
        this.onStateChange = null;
    }

    // === ACTIVITY MANAGEMENT ===
    addActivity(activity, position = 'bottom') {
        if (this.activities.length >= CONFIG.MAX_ACTIVITIES) {
            throw new Error(`Maximum of ${CONFIG.MAX_ACTIVITIES} activities allowed.`);
        }

        const newActivity = {
            title: activity.title || 'New Activity',
            description: activity.description || '',
            icon: activity.icon || CONFIG.DEFAULT_EMOJI,
            visible: activity.visible !== undefined ? activity.visible : true,
            completed: activity.completed || false
        };

        if (position === 'top') {
            this.activities.unshift(newActivity);
        } else {
            this.activities.push(newActivity);
        }
        
        this._triggerSave();
    }

    updateActivity(index, updates) {
        if (index >= 0 && index < this.activities.length) {
            Object.assign(this.activities[index], updates);
            this._triggerSave();
        }
    }

    removeActivity(index) {
        if (index >= 0 && index < this.activities.length) {
            this.activities.splice(index, 1);
            this._triggerSave();
        }
    }

    moveActivity(fromIndex, toIndex) {
        if (fromIndex >= 0 && fromIndex < this.activities.length &&
            toIndex >= 0 && toIndex < this.activities.length) {
            const [removed] = this.activities.splice(fromIndex, 1);
            this.activities.splice(toIndex, 0, removed);
            this._triggerSave();
        }
    }

    toggleActivityVisibility(index) {
        if (index >= 0 && index < this.activities.length) {
            this.activities[index].visible = !this.activities[index].visible;
            this._triggerSave();
        }
    }

    toggleActivityCompletion(index) {
        if (index >= 0 && index < this.activities.length) {
            this.activities[index].completed = !this.activities[index].completed;
            this._triggerSave();
        }
    }

    // === SETTINGS MANAGEMENT ===
    updateTitle(title) {
        this.settings.title = title;
        this.settings.isDefaultTitle = (title === 'My StackMap');
        this._triggerSave();
    }

    updateTheme(color) {
        this.settings.backgroundColor = color;
        this.applyTheme();
        this._triggerSave();
    }

    applyTheme() {
        const color = this.settings.backgroundColor || CONFIG.DEFAULT_COLOR;
        
        // Ensure color is defined and is a string
        if (!color || typeof color !== 'string') {
            console.warn('Invalid color value:', color);
            return;
        }
        
        // Extract RGB values
        const hex = color.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        
        // Create darker variant
        const darkerR = Math.max(0, r - 30);
        const darkerG = Math.max(0, g - 30);
        const darkerB = Math.max(0, b - 30);
        const darkerColor = `rgb(${darkerR}, ${darkerG}, ${darkerB})`;
        
        // Update CSS variables
        document.documentElement.style.setProperty('--primary-color', color);
        document.documentElement.style.setProperty('--primary-dark', darkerColor);
        document.documentElement.style.setProperty('--background-gradient-start', color);
        document.documentElement.style.setProperty('--background-gradient-end', darkerColor);
        
        // Update fixed header background immediately
        const fixedHeader = document.querySelector('.fixed-header');
        if (fixedHeader) {
            fixedHeader.style.background = `${color} !important`;
        }
        
        // Update body background
        document.body.style.background = color;
        
        // Update card number backgrounds
        document.querySelectorAll('.card__number').forEach(el => {
            el.style.background = color;
        });
        
        // Update logo colors if PreferencesManager exists
        if (window.appInstance && window.appInstance.preferencesManager) {
            window.appInstance.preferencesManager.updateLogoColors(color);
        }
    }

    // === DATA EXPORT/IMPORT ===
    exportData() {
        return {
            version: CONFIG.DATA_VERSION,
            activities: this.activities,
            settings: this.settings
        };
    }

    importData(data) {
        if (data.activities && Array.isArray(data.activities)) {
            this.activities = data.activities.slice(0, CONFIG.MAX_ACTIVITIES);
        }
        
        if (data.settings) {
            // Ensure backgroundColor exists before assigning
            if (!data.settings.backgroundColor) {
                data.settings.backgroundColor = CONFIG.DEFAULT_COLOR;
            }
            Object.assign(this.settings, data.settings);
            // Ensure we have the new subtitle field
            if (!this.settings.subtitle) {
                this.settings.subtitle = 'Routine Ready';
            }
            this.applyTheme();
        }
        
        this._triggerSave();
    }

    // === PRIVATE METHODS ===
    _triggerSave() {
        if (this.onStateChange) {
            this.onStateChange();
        }
    }
}

// Make available globally
window.AppState = AppState;