// components.js - Component builder and UI components
// === COMPONENT BUILDER ===
// NO ES6 IMPORTS - This file is loaded via script tag

// The emoji data is loaded from emoji-list.js and emoji-names.js
// They should be available as global constants EMOJIS and EMOJI_NAMES

class ComponentBuilder {
    static createElement(tag, className, attributes = {}) {
        const element = document.createElement(tag);
        if (className) element.className = className;
        
        // Apply attributes if provided
        Object.keys(attributes).forEach(key => {
            if (key === 'innerHTML') {
                element.innerHTML = attributes[key];
            } else {
                element.setAttribute(key, attributes[key]);
            }
        });
        
        return element;
    }

    static createCard(activity, index, appState, renderer, app) {
        return new ActivityCard(activity, index, appState, renderer, app).render();
    }

    static createNewCard(appState, position = 'top') {
        const newCard = this.createElement('div', 'new-card', {
            onclick: `appInstance.openNewCardForm('${position}')`
        });
        
        newCard.innerHTML = `
            <div class="new-card__icon">➕</div>
            <div class="new-card__title">Add New Activity</div>
            <div class="new-card__description">Click to create a new card</div>
        `;
        
        return newCard;
    }

    static createEditInfoCard() {
        const card = this.createElement('div', 'card edit-info-card');
        
        card.innerHTML = `
            <div class="card__icon">✏️</div>
            <div class="card__title">Edit Mode Active</div>
            <div class="card__description">
                • Click any card to edit<br>
                • Drag cards to reorder<br>
                • Use buttons for quick actions
            </div>
        `;
        
        return card;
    }

    static createActivityForm(selectedEmoji, isNewCard = true, activity = null, index = -1) {
        const emoji = isNewCard ? selectedEmoji : activity.icon;
        const titleValue = isNewCard ? '' : activity.title;
        const descValue = isNewCard ? '' : activity.description;
        const titleId = isNewCard ? 'newActivityTitle' : `editTitle${index}`;
        const descId = isNewCard ? 'newActivityDescription' : `editDescription${index}`;
        const iconId = isNewCard ? 'newActivityIcon' : `editIcon${index}`;
        const filterId = isNewCard ? 'newCardEmoji' : `cardEmoji${index}`;
        
        const form = this.createElement('div', 'panel');
        
        form.innerHTML = `
            <h2 class="panel__title">${isNewCard ? 'Add New Activity' : 'Edit Activity'}</h2>
            <div class="card__icon card__icon--editable" id="${iconId}" 
                 onclick="document.getElementById('${filterId}').focus()">${emoji}</div>
            <div class="emoji-picker-slot" data-filter-id="${filterId}" data-icon-id="${iconId}"></div>
            <input type="text" class="form-field form-field--title" id="${titleId}" 
                   placeholder="Activity Title" value="${titleValue}" maxlength="${CONFIG.MAX_TITLE_LENGTH}">
            <input type="text" class="form-field form-field--description" id="${descId}" 
                   placeholder="Description (optional)" value="${descValue}" maxlength="${CONFIG.MAX_DESCRIPTION_LENGTH}">
            <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: center;">
                ${isNewCard ? 
                    `<button class="btn btn--primary" onclick="appInstance.addActivity()">Add Activity</button>
                     <button class="btn btn--secondary" onclick="appInstance.clearNewActivity()">Cancel</button>` :
                    `<button class="btn btn--primary" onclick="appInstance.saveCardEdit(${index})">Save</button>
                     <button class="btn btn--secondary" onclick="appInstance.cancelCardEdit()">Cancel</button>`
                }
            </div>
        `;
        
        // Replace emoji picker slot with actual picker after form is created
        setTimeout(() => {
            const slot = form.querySelector('.emoji-picker-slot');
            if (slot) {
                const filterId = slot.getAttribute('data-filter-id');
                const iconId = slot.getAttribute('data-icon-id');
                const picker = this.createEmojiPicker(
                    emoji,
                    (emoji) => {
                        const iconElement = document.getElementById(iconId);
                        if (iconElement) iconElement.textContent = emoji;
                        if (isNewCard) {
                            appInstance.selectNewEmoji(emoji);
                        } else {
                            // For edit mode, update the activity directly
                            if (appInstance.appState.activities[index]) {
                                appInstance.appState.activities[index].icon = emoji;
                            }
                        }
                    },
                    filterId
                );
                slot.replaceWith(picker);
            }
        }, 0);
        
        return form;
    }

    // Delegate to EmojiPicker class
    static createEmojiPicker(selectedEmoji, onEmojiSelect, filterId) {
        return EmojiPicker.createEmojiPicker(selectedEmoji, onEmojiSelect, filterId);
    }
}

// === ENHANCED EMOJI PICKER COMPONENT ===
class EmojiPicker {
    static createEmojiPicker(selectedEmoji, onEmojiSelect, filterId) {
        const picker = ComponentBuilder.createElement('div', 'emoji-picker');
        
        // Add header section
        const header = ComponentBuilder.createElement('div', 'emoji-picker__header');
        
        // Unified search/paste input
        const filter = ComponentBuilder.createElement('input', 'emoji-picker__filter');
        filter.type = 'text';
        filter.placeholder = 'Search emojis or paste your own...';
        filter.id = filterId;
        
        // Add hint text
        const hint = ComponentBuilder.createElement('div', 'emoji-picker__hint');
        hint.innerHTML = '💡 Tip: Paste any emoji or search by keywords like "face", "happy", "dark skin"';
        
        // Grid for our emojis
        const grid = ComponentBuilder.createElement('div', 'emoji-picker__grid');
        grid.id = `${filterId}_grid`;
        
        // Assembly
        header.appendChild(filter);
        header.appendChild(hint);
        picker.appendChild(header);
        picker.appendChild(grid);
        
        // Populate grid immediately
        this.renderEmojiGrid(grid, selectedEmoji, onEmojiSelect, EMOJIS || []);
        
        // Emoji regex pattern - matches emojis
        const emojiRegex = /\p{Emoji_Presentation}|\p{Emoji}\uFE0F/u;
        
        // Handle unified input
        filter.addEventListener('input', (e) => {
            const value = e.target.value.trim();
            
            // Check if input contains emoji
            const emojiMatch = value.match(emojiRegex);
            if (emojiMatch) {
                // User pasted/typed an emoji - select it immediately
                onEmojiSelect(emojiMatch[0]);
                filter.value = '';
                this.showSuccess(filter, 'Emoji selected!');
                // Reset grid to show all
                this.renderEmojiGrid(grid, selectedEmoji, onEmojiSelect, EMOJIS || []);
            } else if (value) {
                // Search functionality
                const filteredEmojis = this.smartEmojiSearch(value);
                
                if (filteredEmojis.length === 0) {
                    grid.innerHTML = `
                        <div style="grid-column: 1 / -1; text-align: center; padding: 20px; color: #666; font-size: 0.9rem;">
                            No emojis found for "${value}"<br>
                            Try: "face", "animal", "food", "light skin", "red hair", "family"
                        </div>
                    `;
                } else {
                    this.renderEmojiGrid(grid, selectedEmoji, onEmojiSelect, filteredEmojis);
                }
            } else {
                // Empty input - show all
                this.renderEmojiGrid(grid, selectedEmoji, onEmojiSelect, EMOJIS || []);
            }
        });
        
        // Handle paste event for better emoji detection
        filter.addEventListener('paste', (e) => {
            e.preventDefault();
            const pastedText = (e.clipboardData || window.clipboardData).getData('text');
            const emojiMatch = pastedText.match(emojiRegex);
            
            if (emojiMatch) {
                onEmojiSelect(emojiMatch[0]);
                filter.value = '';
                this.showSuccess(filter, 'Emoji pasted!');
            } else {
                // If not an emoji, treat as search
                filter.value = pastedText;
                filter.dispatchEvent(new Event('input'));
            }
        });
        
        return picker;
    }
    
    static smartEmojiSearch(searchTerm) {
        const terms = searchTerm.toLowerCase().split(' ').filter(t => t.length > 0);
        
        // Process skin tone and hair terms
        const processedTerms = this.processSearchTerms(terms);
        
        return (EMOJIS || []).filter(emoji => {
            const keywords = ((EMOJI_NAMES || {})[emoji] || '').toLowerCase();
            
            // Check if all processed terms match
            return processedTerms.every(term => {
                // Direct emoji match
                if (emoji === term) return true;
                
                // Keyword match
                if (keywords.includes(term)) return true;
                
                // Synonym matching
                const synonyms = this.getSynonyms(term);
                return synonyms.some(syn => keywords.includes(syn));
            });
        });
    }
    
    static processSearchTerms(terms) {
        const processed = [];
        let skipNext = false;
        
        for (let i = 0; i < terms.length; i++) {
            if (skipNext) {
                skipNext = false;
                continue;
            }
            
            // Check for skin tone combinations
            if (i < terms.length - 1) {
                const combined = this.normalizeSkinTone(terms[i], terms[i + 1]);
                if (combined) {
                    processed.push(combined);
                    skipNext = true;
                    continue;
                }
            }
            
            // Single term normalization
            const normalized = this.normalizeTerm(terms[i]);
            if (normalized) {
                processed.push(normalized);
            }
        }
        
        return processed;
    }
    
    static normalizeSkinTone(term1, term2) {
        const skinToneMap = {
            'light skin': 'light skin',
            'pale skin': 'light skin',
            'white skin': 'light skin',
            'fair skin': 'light skin',
            'medium skin': 'medium skin',
            'olive skin': 'medium skin',
            'tan skin': 'medium light skin',
            'brown skin': 'medium skin',
            'dark skin': 'dark skin',
            'black skin': 'dark skin'
        };
        
        const combined = `${term1} ${term2}`;
        return skinToneMap[combined] || null;
    }
    
    static normalizeTerm(term) {
        const termMap = {
            'light': 'light skin',
            'pale': 'light skin',
            'white': 'light skin',
            'fair': 'light skin',
            'medium': 'medium skin',
            'olive': 'medium skin',
            'tan': 'medium light skin',
            'brown': 'medium skin',
            'dark': 'dark skin',
            'black': 'dark skin',
            'mom': 'mother',
            'dad': 'father',
            'mommy': 'mother',
            'daddy': 'father',
            'kid': 'child',
            'kids': 'children'
        };
        
        return termMap[term] || term;
    }
    
    static getSynonyms(term) {
        const synonymMap = {
            'happy': ['smile', 'joy', 'cheerful', 'glad'],
            'sad': ['unhappy', 'crying', 'tears', 'upset'],
            'angry': ['mad', 'frustrated', 'annoyed'],
            'family': ['parents', 'children', 'mother', 'father'],
            'boy': ['son', 'male', 'child'],
            'girl': ['daughter', 'female', 'child'],
            'man': ['male', 'father', 'dad'],
            'woman': ['female', 'mother', 'mom'],
            'baby': ['infant', 'newborn'],
            'food': ['eat', 'meal', 'breakfast', 'lunch', 'dinner'],
            'animal': ['pet', 'creature'],
            'work': ['job', 'office', 'professional'],
            'school': ['education', 'learn', 'study']
        };
        
        return synonymMap[term] || [];
    }
    
    static showSuccess(input, message) {
        const parent = input.parentElement;
        const existing = parent.querySelector('.emoji-picker__feedback');
        if (existing) existing.remove();
        
        const feedback = ComponentBuilder.createElement('div', 'emoji-picker__feedback emoji-picker__feedback--success');
        feedback.textContent = message;
        parent.appendChild(feedback);
        
        setTimeout(() => feedback.remove(), 2000);
    }
    
    static showError(input, message) {
        const parent = input.parentElement;
        const existing = parent.querySelector('.emoji-picker__feedback');
        if (existing) existing.remove();
        
        const feedback = ComponentBuilder.createElement('div', 'emoji-picker__feedback emoji-picker__feedback--error');
        feedback.textContent = message;
        parent.appendChild(feedback);
        
        setTimeout(() => feedback.remove(), 3000);
    }

    static renderEmojiGrid(grid, selectedEmoji, onEmojiSelect, emojis) {
        grid.innerHTML = '';
        
        // Add safety check
        if (!emojis || !Array.isArray(emojis) || emojis.length === 0) {
            grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 20px; color: #666;">No emojis available</div>';
            return;
        }
        
        emojis.forEach(emoji => {
            const button = ComponentBuilder.createElement('button', 'emoji-picker__option');
            button.textContent = emoji;
            button.title = (EMOJI_NAMES || {})[emoji] || emoji;
            button.type = 'button';
            
            if (emoji === selectedEmoji) {
                button.classList.add('emoji-picker__option--selected');
            }
            
            button.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Update selection
                grid.querySelectorAll('.emoji-picker__option').forEach(opt => {
                    opt.classList.remove('emoji-picker__option--selected');
                });
                button.classList.add('emoji-picker__option--selected');
                
                // Call callback
                if (typeof onEmojiSelect === 'function') {
                    onEmojiSelect(emoji);
                }
            });
            
            grid.appendChild(button);
        });
    }
}

// === ENHANCED ACTIVITY CARD COMPONENT ===
class ActivityCard {
    constructor(activity, index, appState, renderer, app) {
        this.activity = activity;
        this.index = index;
        this.appState = appState;
        this.renderer = renderer;
        this.app = app;
    }

    render() {
        const { editMode, editingCardIndex } = this.appState.ui;
        const { backgroundColor, showNumbers, showCompletionIndicators } = this.appState.settings;
        const isEditing = editingCardIndex === this.index;
        
        // Create card with completion state
        const completedClass = this.activity.completed ? 'card--completed' : '';
        const hiddenClass = !this.activity.visible ? 'card--hidden' : '';
        
        const card = ComponentBuilder.createElement('div', 
            `card ${completedClass} ${hiddenClass}`, 
            { 'data-index': this.index }
        );

        // CARD CLICK BEHAVIOR - Updated to respect completion indicators setting
        if (!editMode) {
            // Child mode: click to complete only if indicators are shown
            if (showCompletionIndicators !== false) {
                card.onclick = (e) => this.handleClick(e);
                card.style.cursor = 'pointer';
            } else {
                card.style.cursor = 'default';
            }
        } else {
            // Grown-up mode: click to edit
            card.onclick = (e) => this.handleEditClick(e);
            card.style.cursor = 'pointer';
            card.title = 'Click to edit this card';
        }

        this.setupDragAndDrop(card);

        if (isEditing) {
            card.innerHTML = this.renderEditMode(backgroundColor);
            
            // Insert emoji picker directly
            const slot = card.querySelector('.emoji-picker-slot');
            if (slot) {
                const picker = ComponentBuilder.createEmojiPicker(
                    this.activity.icon,
                    (emoji) => {
                        this.activity.icon = emoji;
                        const iconElement = document.getElementById(`editIcon${this.index}`);
                        if (iconElement) iconElement.textContent = emoji;
                    },
                    `cardEmoji${this.index}`
                );
                slot.replaceWith(picker);
            }
        } else {
            card.innerHTML = this.renderViewMode(backgroundColor, showNumbers);
        }

        return card;
    }

    renderViewMode(backgroundColor, showNumbers) {
        const { editMode } = this.appState.ui;
        const displayIndex = this.getDisplayIndex();
        
        return `
            ${!editMode && showNumbers ? `<div class="card__number" style="background: ${backgroundColor};">${displayIndex + 1}</div>` : ''}
            ${editMode ? this.renderEditButtons() : ''}
            <div class="card__icon">${this.activity.icon}</div>
            <div class="card__title">${this.activity.title}</div>
            <div class="card__description">${this.activity.description}</div>
        `;
    }

    renderEditMode(backgroundColor) {
        return `
            ${this.renderEditButtons()}
            <div class="card__icon" id="editIcon${this.index}">${this.activity.icon}</div>
            <div class="emoji-picker-slot"></div>
            <input type="text" class="form-field form-field--title" 
                   value="${this.activity.title}" id="editTitle${this.index}" maxlength="${CONFIG.MAX_TITLE_LENGTH}">
            <input type="text" class="form-field form-field--description" 
                   value="${this.activity.description}" id="editDescription${this.index}" maxlength="${CONFIG.MAX_DESCRIPTION_LENGTH}">
            <div style="margin-top: 15px; display: flex; gap: 10px; justify-content: center;">
                <button class="btn btn--primary" onclick="appInstance.saveCardEdit(${this.index})">Save</button>
                <button class="btn btn--secondary" onclick="appInstance.cancelCardEdit()">Cancel</button>
            </div>
        `;
    }

    renderEditButtons() {
        // In grown-up mode, show completion checkbox in top-left
        const checkboxIcon = '✓';
        const checkboxBg = this.activity.completed ? 'var(--primary-color)' : '#e8e8e8';
        const checkboxColor = this.activity.completed ? 'white' : '#999';
        
        return `
            <button class="btn btn--round btn--checkbox" 
                    style="top: 10px; left: 15px; background: ${checkboxBg}; color: ${checkboxColor}; font-size: 1.35rem; font-weight: 900; font-family: inherit; line-height: 1; padding: 0;" 
                    onclick="event.stopPropagation(); appInstance.toggleGrownupCompletion(${this.index})" 
                    aria-label="Toggle completion" title="${this.activity.completed ? 'Mark incomplete' : 'Mark complete'}">✓</button>
            
            <button class="btn btn--round btn--visibility ${!this.activity.visible ? 'btn--visibility--hidden' : ''}" 
                    style="top: 10px; right: 15px;"
                    onclick="event.stopPropagation(); appInstance.toggleVisibility(${this.index})" 
                    aria-label="Toggle visibility" title="${this.activity.visible ? 'Hide from routine' : 'Show in routine'}">
                <span class="material-icons">${this.activity.visible ? 'visibility' : 'visibility_off'}</span>
            </button>
            <button class="btn btn--round btn--duplicate" 
                    style="bottom: 10px; right: 15px;"
                    onclick="event.stopPropagation(); appInstance.duplicateActivity(${this.index})" 
                    aria-label="Duplicate card" title="Make a copy">
                <span class="material-icons">content_copy</span>
            </button>
            <button class="btn btn--round btn--delete" 
                    style="bottom: 10px; left: 15px;"
                    onclick="event.stopPropagation(); appInstance.deleteActivity(${this.index})" 
                    aria-label="Delete card" title="Delete card">
                <span class="material-icons">delete</span>
            </button>
        `;
    }

    getDisplayIndex() {
        const visibleActivities = this.appState.activities.filter(a => a.visible);
        return visibleActivities.indexOf(this.activity);
    }

    // CHILD MODE: Click to complete (only if indicators are enabled)
    handleClick(e) {
        if (!e.target.closest('.card').classList.contains('card--dragging')) {
            if (this.appState.settings.showCompletionIndicators !== false) {
                this.toggleComplete();
            }
        }
    }

    // GROWN-UP MODE: Click to edit
    handleEditClick(e) {
        // Don't trigger edit if clicking on buttons
        if (e.target.closest('button')) {
            return;
        }
        
        // Start editing this card
        this.app.startCardEdit(this.index);
    }

    toggleComplete() {
        const card = document.querySelector(`[data-index="${this.index}"]`);
        if (!card) return;

        // Toggle completion in state AND save it
        this.appState.toggleActivityCompletion(this.index);
        
        const wasCompleted = card.classList.contains('card--completed');
        card.classList.toggle('card--completed');

        if (!wasCompleted) {
            // Check if all visible cards are now completed
            const visibleActivities = this.appState.activities.filter(a => a.visible);
            const allCards = document.querySelectorAll('.card:not(.card--hidden)');
            const completedCards = document.querySelectorAll('.card--completed:not(.card--hidden)');
            
            if (completedCards.length === visibleActivities.length && visibleActivities.length > 0) {
                this.renderer.createFireworks();
            } else {
                this.renderer.createConfetti();
            }
        }
    }

    setupDragAndDrop(card) {
        if (!card) return;
        
        card.draggable = true;
        
        card.addEventListener('dragstart', (e) => {
            if (!this.appState.ui.editMode) {
                e.preventDefault();
                return;
            }
            
            console.log('Drag start:', e.target.dataset.index);
            this.appState.ui.draggedElement = e.target;
            this.draggedIndex = parseInt(e.target.dataset.index);
            
            e.target.classList.add('card--dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/html', '');
            
            // Add visual feedback to other cards
            setTimeout(() => {
                document.querySelectorAll('.card:not(.card--dragging)').forEach(c => {
                    c.classList.add('card--droppable');
                });
            }, 50);
        });
        
        card.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            
            if (!this.appState.ui.draggedElement) return;
            
            const targetCard = e.target.closest('.card');
            if (!targetCard || targetCard.classList.contains('card--dragging')) return;
            
            // Clear previous highlights
            document.querySelectorAll('.card--drop-target').forEach(c => {
                c.classList.remove('card--drop-target');
            });
            
            // Add highlight to current target
            targetCard.classList.add('card--drop-target');
            
            // Live sorting animation
            this.animateLiveSort(targetCard);
        });
        
        card.addEventListener('drop', (e) => {
            e.preventDefault();
            console.log('Drop event');
            
            const draggedElement = this.appState.ui.draggedElement;
            const targetCard = e.target.closest('.card');
            
            if (!draggedElement || !targetCard || draggedElement === targetCard) return;
            
            const draggedIndex = parseInt(draggedElement.dataset.index);
            const targetIndex = parseInt(targetCard.dataset.index);
            
            console.log('Moving from', draggedIndex, 'to', targetIndex);
            
            if (!isNaN(draggedIndex) && !isNaN(targetIndex) && draggedIndex !== targetIndex) {
                this.appState.moveActivity(draggedIndex, targetIndex);
                this.renderer.render();
            }
        });
        
        card.addEventListener('dragend', (e) => {
            console.log('Drag end');
            this.cleanupDragStates();
        });
        
        card.addEventListener('dragleave', (e) => {
            const targetCard = e.target.closest('.card');
            if (targetCard && !targetCard.contains(e.relatedTarget)) {
                targetCard.classList.remove('card--drop-target');
            }
        });
    }
    
    animateLiveSort(targetCard) {
        if (!this.appState.ui.draggedElement || !targetCard) return;
        
        const draggedIndex = this.draggedIndex;
        const targetIndex = parseInt(targetCard.dataset.index);
        
        if (isNaN(draggedIndex) || isNaN(targetIndex) || draggedIndex === targetIndex) return;
        
        // Get container and calculate card dimensions
        const container = targetCard.parentElement;
        const cards = Array.from(container.querySelectorAll('.card:not(.card--dragging)'));
        const firstCard = cards[0];
        if (!firstCard) return;
        
        const cardRect = firstCard.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        const cardsPerRow = Math.floor(containerRect.width / cardRect.width);
        const gap = 20; // Match CSS gap
        
        // Clear previous animations
        cards.forEach(card => {
            card.style.transform = '';
            card.style.transition = '';
            card.classList.remove('card--shifting');
        });
        
        // Animate cards that need to move
        cards.forEach(card => {
            const cardIndex = parseInt(card.dataset.index);
            if (isNaN(cardIndex)) return;
            
            let translateX = 0;
            let translateY = 0;
            
            if (draggedIndex < targetIndex) {
                // Dragging down: cards between dragged and target move up/left
                if (cardIndex > draggedIndex && cardIndex <= targetIndex) {
                    const currentRow = Math.floor(cardIndex / cardsPerRow);
                    const currentCol = cardIndex % cardsPerRow;
                    const newIndex = cardIndex - 1;
                    const newRow = Math.floor(newIndex / cardsPerRow);
                    const newCol = newIndex % cardsPerRow;
                    
                    translateX = (newCol - currentCol) * (cardRect.width + gap);
                    translateY = (newRow - currentRow) * (cardRect.height + gap);
                }
            } else {
                // Dragging up: cards between target and dragged move down/right
                if (cardIndex >= targetIndex && cardIndex < draggedIndex) {
                    const currentRow = Math.floor(cardIndex / cardsPerRow);
                    const currentCol = cardIndex % cardsPerRow;
                    const newIndex = cardIndex + 1;
                    const newRow = Math.floor(newIndex / cardsPerRow);
                    const newCol = newIndex % cardsPerRow;
                    
                    translateX = (newCol - currentCol) * (cardRect.width + gap);
                    translateY = (newRow - currentRow) * (cardRect.height + gap);
                }
            }
            
            if (translateX !== 0 || translateY !== 0) {
                card.style.transform = `translate(${translateX}px, ${translateY}px)`;
                card.style.transition = 'transform 0.25s cubic-bezier(0.2, 0, 0.2, 1)';
                card.classList.add('card--shifting');
            }
        });
    }
    
    cleanupDragStates() {
        // Remove all drag-related classes and styles
        document.querySelectorAll('.card').forEach(card => {
            card.classList.remove('card--dragging', 'card--drop-target', 'card--droppable', 'card--shifting');
            card.style.transform = '';
            card.style.transition = '';
        });
        
        this.appState.ui.draggedElement = null;
        this.draggedIndex = null;
    }
}

// Make classes globally available (no ES6 exports)
window.ComponentBuilder = ComponentBuilder;
window.ActivityCard = ActivityCard;
window.EmojiPicker = EmojiPicker;