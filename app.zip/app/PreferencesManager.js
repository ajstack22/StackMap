// app/PreferencesManager.js - Preferences panel management with settings
// === PREFERENCES PANEL MANAGER ===
class PreferencesManager {
    constructor(app) {
        this.app = app;
        this.scrollPosition = 0;
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Set up preferences button click handler
        const preferencesBtn = document.getElementById('preferencesBtn');
        if (preferencesBtn) {
            preferencesBtn.addEventListener('click', () => this.togglePreferences());
        }

        // Close panels when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.preferences-panel') && !e.target.closest('#preferencesBtn')) {
                this.closePreferences();
            }
        });
    }

    // PREFERENCES PANEL MANAGEMENT
    togglePreferences() {
        const panel = document.getElementById('preferencesPanel');
        
        if (panel.classList.contains('hidden')) {
            this.showPreferences();
        } else {
            this.closePreferences();
        }
    }

    showPreferences() {
        const panel = document.getElementById('preferencesPanel');
        this.updatePreferencesPanel();
        panel.classList.remove('hidden');
        
        // Prevent background scrolling on mobile while preserving gradient
        if (window.innerWidth <= 768) {
            // Store current scroll position
            this.scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
            
            // Get the current background before making changes
            const bodyStyle = window.getComputedStyle(document.body);
            const currentBackground = bodyStyle.backgroundImage || bodyStyle.background;
            
            // Set overflow hidden on html element to prevent scroll
            document.documentElement.style.overflow = 'hidden';
            document.documentElement.style.height = '100%';
            
            // Keep body in normal flow but prevent scroll
            document.body.style.overflow = 'hidden';
            document.body.style.height = '100%';
            
            // Ensure background gradient stays intact
            if (currentBackground && currentBackground !== 'none') {
                document.body.style.backgroundImage = currentBackground;
            }
        }
    }

    closePreferences() {
        const panel = document.getElementById('preferencesPanel');
        panel.classList.add('hidden');
        
        // Restore scrolling
        if (window.innerWidth <= 768) {
            // Remove overflow restrictions
            document.documentElement.style.overflow = '';
            document.documentElement.style.height = '';
            document.body.style.overflow = '';
            document.body.style.height = '';
            
            // Restore scroll position
            if (this.scrollPosition !== undefined) {
                window.scrollTo(0, this.scrollPosition);
                this.scrollPosition = undefined;
            }
        }
    }

    updatePreferencesPanel() {
        const contentDiv = document.getElementById('preferencesContent');
        
        if (this.app.grownupMode) {
            // Grown-up mode: Settings with data management and sync
            contentDiv.innerHTML = `
                <h3>Settings</h3>
                <div class="preferences-section">
                    <label>Data Management</label>
                    <div class="data-management-controls" style="display: flex; flex-direction: column; gap: 12px;">
                        <button class="btn btn--primary" onclick="document.getElementById('fileInput').click()" style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                            <span class="material-icons">inbox</span>
                            Import StackMap
                        </button>
                        <button class="btn btn--primary" onclick="appInstance.exportToFile()" style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                            <span class="material-icons">outbox</span>
                            Export StackMap
                        </button>
                    </div>
                </div>
                <div class="preferences-section">
                    <label>Google Drive Sync</label>
                    <div class="sync-controls">
                        <button class="btn btn--secondary" id="googleSignInBtn" onclick="appInstance.driveSync.signIn()" style="background: #888; color: white;">
                            Connect Google Drive
                        </button>
                        <div class="sync-status" id="syncStatus" style="display: none;">
                            <div class="sync-user" id="syncUser">Connected to Google Drive</div>
                        </div>
                        <div class="sync-actions" id="syncActions" style="display: none; flex-direction: column; gap: 8px;">
                            <button class="btn btn--secondary btn--small" onclick="appInstance.driveSync.uploadData()">
                                <span class="material-icons">cloud_upload</span>
                                Save to Drive
                            </button>
                            <button class="btn btn--secondary btn--small" onclick="appInstance.driveSync.downloadData()">
                                <span class="material-icons">cloud_download</span>
                                Load from Drive
                            </button>
                            <button class="btn btn--secondary btn--small" onclick="appInstance.driveSync.signOut()">
                                <span class="material-icons">logout</span>
                                Disconnect
                            </button>
                        </div>
                    </div>
                </div>
                <div class="preferences-hint" style="background: rgba(255, 193, 7, 0.1); padding: 12px; border-radius: 8px; font-size: 0.9rem; color: #856404; text-align: center; margin: 20px 0; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 1.2rem;">💡</span>
                    Tap the title or subtitle above to edit them!
                </div>
                <div class="preferences-footer" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <button class="btn btn--primary" onclick="appInstance.preferencesManager.closePreferences()">Done</button>
                    <button class="btn btn--link" onclick="appInstance.showWelcomeAgain?.()" title="Show welcome tutorial again" style="display: flex; align-items: center; gap: 4px;">
                        <span class="material-icons" style="font-size: 1.1rem;">help_outline</span>
                        Welcome Guide
                    </button>
                </div>
            `;
        } else {
            // Kid mode: Mobile-optimized preferences panel
            const isMobile = window.innerWidth <= 768;
            
            contentDiv.innerHTML = `
                <h3 style="margin: 0 0 ${isMobile ? '8px' : '20px'} 0; font-size: ${isMobile ? '1.2rem' : '1.6rem'}; text-align: center; color: #333;">Preferences</h3>
                
                <div class="preferences-section" style="margin-bottom: ${isMobile ? '8px' : '20px'};">
                    <label style="display: block; margin-bottom: ${isMobile ? '4px' : '10px'}; font-size: ${isMobile ? '0.8rem' : '0.95rem'}; font-weight: 600; color: #333;">Choose Your Theme Color</label>
                    <div class="color-picker" id="preferencesColorPicker" style="display: grid; grid-template-columns: repeat(6, 1fr); gap: ${isMobile ? '3px' : '6px'};"></div>
                </div>
                
                <div class="preferences-section" style="margin-bottom: ${isMobile ? '6px' : '16px'};">
                    <label class="preferences-checkbox" style="display: flex; align-items: center; gap: ${isMobile ? '6px' : '10px'}; font-size: ${isMobile ? '0.8rem' : '0.95rem'}; cursor: pointer;">
                        <input type="checkbox" id="preferencesNumberToggle" ${this.app.appState.settings.showNumbers ? 'checked' : ''} style="width: ${isMobile ? '16px' : '18px'}; height: ${isMobile ? '16px' : '18px'}; cursor: pointer; flex-shrink: 0;">
                        <span style="color: #333; font-weight: 500;">Show Card Numbers</span>
                    </label>
                </div>
                
                <div class="preferences-section" style="margin-bottom: ${isMobile ? '12px' : '24px'};">
                    <label class="preferences-checkbox" style="display: flex; align-items: center; gap: ${isMobile ? '6px' : '10px'}; font-size: ${isMobile ? '0.8rem' : '0.95rem'}; cursor: pointer;">
                        <input type="checkbox" id="preferencesCompletionToggle" ${this.app.appState.settings.showCompletionIndicators !== false ? 'checked' : ''} style="width: ${isMobile ? '16px' : '18px'}; height: ${isMobile ? '16px' : '18px'}; cursor: pointer; flex-shrink: 0;">
                        <span style="color: #333; font-weight: 500;">Show Completion Checkmarks</span>
                    </label>
                </div>
                
                <div class="preferences-footer" style="display: flex; justify-content: center;">
                    <button class="btn btn--primary" onclick="appInstance.preferencesManager.closePreferences()" style="padding: ${isMobile ? '6px 20px' : '10px 28px'}; font-size: ${isMobile ? '0.9rem' : '1.05rem'}; font-weight: 600;">Done</button>
                </div>
            `;
            
            // Setup color picker and checkbox for kid mode
            setTimeout(() => {
                this.setupKidModeControls();
            }, 0);
        }
        
        // Update sync controls if in grown-up mode
        if (this.app.grownupMode) {
            setTimeout(() => {
                this.updateSyncControls();
            }, 0);
        }
    }

    setupKidModeControls() {
        const isMobile = window.innerWidth <= 768;
        
        // Setup color picker with improved styling
        const colorPicker = document.getElementById('preferencesColorPicker');
        if (colorPicker && THEMES && THEMES.COLORS) {
            colorPicker.innerHTML = THEMES.COLORS.map(color => {
                const isSelected = color === this.app.appState.settings.backgroundColor;
                // Make color squares even smaller on mobile
                const size = isMobile ? '28px' : '45px';
                return `<div class="color-picker__option ${isSelected ? 'color-picker__option--selected' : ''}" 
                             style="background-color: ${color}; width: 100%; height: ${size}; border-radius: ${isMobile ? '4px' : '6px'}; cursor: pointer; transition: all 0.2s ease; border: 2px solid ${isSelected ? '#333' : 'transparent'}; position: relative; box-sizing: border-box;" 
                             onclick="appInstance.selectColor('${color}')" 
                             title="${color}">
                             ${isSelected ? `<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-size: ${isMobile ? '12px' : '16px'}; font-weight: bold; text-shadow: 0 0 3px rgba(0,0,0,0.8);">✓</div>` : ''}
                        </div>`;
            }).join('');
        }
        
        // Setup number toggle with proper event handling
        const numberToggle = document.getElementById('preferencesNumberToggle');
        if (numberToggle) {
            // Remove any existing event listeners to prevent duplicates
            const newNumberToggle = numberToggle.cloneNode(true);
            numberToggle.parentNode.replaceChild(newNumberToggle, numberToggle);
            
            // Add event listener to the new element
            newNumberToggle.addEventListener('change', (e) => {
                this.app.appState.settings.showNumbers = e.target.checked;
                this.app.appState._triggerSave();
                this.app.render();
            });
        }
        
        // Setup completion indicators toggle
        const completionToggle = document.getElementById('preferencesCompletionToggle');
        if (completionToggle) {
            // Remove any existing event listeners to prevent duplicates
            const newCompletionToggle = completionToggle.cloneNode(true);
            completionToggle.parentNode.replaceChild(newCompletionToggle, completionToggle);
            
            // Add event listener to the new element
            newCompletionToggle.addEventListener('change', (e) => {
                this.app.appState.settings.showCompletionIndicators = e.target.checked;
                this.app.appState._triggerSave();
                
                // Update body class to hide/show completion indicators
                if (e.target.checked) {
                    document.body.classList.remove('hide-completion-indicators');
                } else {
                    document.body.classList.add('hide-completion-indicators');
                }
                
                this.app.render();
            });
        }
    }

    updateSyncControls() {
        const signInBtn = document.getElementById('googleSignInBtn');
        const syncStatus = document.getElementById('syncStatus');
        const syncActions = document.getElementById('syncActions');
        
        if (this.app.driveSync.isSignedIn) {
            if (signInBtn) signInBtn.style.display = 'none';
            if (syncStatus) syncStatus.style.display = 'flex';
            if (syncActions) syncActions.style.display = 'flex';
        } else {
            if (signInBtn) signInBtn.style.display = 'block';
            if (syncStatus) syncStatus.style.display = 'none';
            if (syncActions) syncActions.style.display = 'none';
        }
    }

    createColorPickerHTML(selectedColor) {
        if (!THEMES || !THEMES.COLORS) return '';
        return THEMES.COLORS.map(color => {
            const isSelected = color === selectedColor;
            return `<div class="color-picker__option ${isSelected ? 'color-picker__option--selected' : ''}" 
                         style="background-color: ${color}; width: 100%; aspect-ratio: 1; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; border: 3px solid ${isSelected ? '#333' : 'transparent'}; position: relative;" 
                         onclick="appInstance.selectColor('${color}')" 
                         title="${color}">
                         ${isSelected ? '<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-size: 20px; font-weight: bold; text-shadow: 0 0 4px rgba(0,0,0,0.5);">✓</div>' : ''}
                    </div>`;
        }).join('');
    }

    // Color selection handler
    selectColor(color) {
        const isMobile = window.innerWidth <= 768;
        this.app.appState.updateTheme(color);
        
        // Update color picker selection state
        const colorPicker = document.getElementById('preferencesColorPicker');
        if (colorPicker) {
            // Remove selected state from all options
            colorPicker.querySelectorAll('.color-picker__option').forEach(option => {
                option.style.border = '2px solid transparent';
                option.innerHTML = '';
            });
            
            // Add selected state to clicked option
            const selectedOption = Array.from(colorPicker.querySelectorAll('.color-picker__option'))
                .find(option => option.style.backgroundColor === color);
            if (selectedOption) {
                selectedOption.style.border = '2px solid #333';
                selectedOption.innerHTML = `<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-size: ${isMobile ? '12px' : '16px'}; font-weight: bold; text-shadow: 0 0 3px rgba(0,0,0,0.8);">✓</div>`;
            }
        }
        
        // Update card numbers with new theme color
        document.querySelectorAll('.card__number').forEach(numberElement => {
            numberElement.style.background = color;
        });
        
        // Update StackMap logo colors
        this.updateLogoColors(color);
        
        // Update header if needed
        if (this.app.syncFixedHeader) {
            this.app.syncFixedHeader();
        }
    }

    // Update StackMap logo colors to match the selected theme
    updateLogoColors(primaryColor) {
        // Create darker variant for bottom rect
        const hex = primaryColor.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        
        // Create darker color for gradient effect
        const darkerR = Math.max(0, r - 60);
        const darkerG = Math.max(0, g - 60);
        const darkerB = Math.max(0, b - 60);
        const darkerColor = `rgb(${darkerR}, ${darkerG}, ${darkerB})`;
        
        // Update all logo instances
        this.updateLogoInstance('mainTitle', primaryColor, darkerColor);
        this.updateLogoInstance('fixedTitle', primaryColor, darkerColor);
        
        // Update welcome screen logo if it exists
        const welcomeLogo = document.querySelector('.welcome-logo svg');
        if (welcomeLogo) {
            this.updateSVGColors(welcomeLogo, primaryColor, darkerColor);
        }
    }

    updateLogoInstance(titleId, primaryColor, darkerColor) {
        const titleElement = document.getElementById(titleId);
        if (titleElement && titleElement.innerHTML.includes('svg')) {
            const svg = titleElement.querySelector('svg');
            if (svg) {
                this.updateSVGColors(svg, primaryColor, darkerColor);
            }
        }
    }

    updateSVGColors(svg, primaryColor, darkerColor) {
        // Update the rect colors in the logo
        const rects = svg.querySelectorAll('rect');
        if (rects.length >= 3) {
            // Top two rects use primary color
            rects[0].setAttribute('fill', primaryColor);
            rects[1].setAttribute('fill', primaryColor);
            // Bottom rect uses darker color
            rects[2].setAttribute('fill', darkerColor);
        }
    }
}